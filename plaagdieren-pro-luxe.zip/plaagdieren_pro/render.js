// Placeholder for environments that expect a render file.
console.log('LPD site loaded');
