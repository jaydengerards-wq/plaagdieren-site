document.addEventListener('DOMContentLoaded', () => {
  const items = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  items.forEach(el => io.observe(el));

  const year = document.querySelector('[data-year]');
  if (year) year.textContent = new Date().getFullYear();

  const form = document.querySelector('#offerte-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('Bedankt! Dit demo-formulier is klaar voor koppeling aan e-mail, Formspree of je hostingpakket.');
    });
  }
});
